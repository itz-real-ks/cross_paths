---
layout: default
title: install.md
---
# Install
pip install cross_paths
