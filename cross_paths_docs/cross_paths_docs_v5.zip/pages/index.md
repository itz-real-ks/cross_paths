---
layout: default
title: index.md
---
# cross_paths
quick example
