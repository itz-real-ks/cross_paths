---
layout: default
title: cli.md
---
# CLI
safe removal and validation
