---
layout: default
title: examples.md
---
# Examples
rmdupes-safe patterns
