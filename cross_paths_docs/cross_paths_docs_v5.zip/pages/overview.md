---
layout: default
title: overview.md
---
# Overview
filesystem operations and duplicate detection
